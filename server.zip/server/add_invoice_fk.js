
const db = require('./db');

async function addConstraint() {
    console.log("🛠️ Adding FK Constraint to transactions(invoice_id)...");
    const client = await db.pool.connect();
    try {
        // 1. Clean up any remaining orphans first (just in case)
        await client.query("DELETE FROM transactions WHERE invoice_id IS NOT NULL AND invoice_id NOT IN (SELECT id FROM invoices)");

        // 2. Add Constraint
        await client.query(`
            ALTER TABLE transactions 
            DROP CONSTRAINT IF EXISTS transactions_invoice_id_fkey;

            ALTER TABLE transactions
            ADD CONSTRAINT transactions_invoice_id_fkey
            FOREIGN KEY (invoice_id) REFERENCES invoices(id)
            ON DELETE CASCADE;
        `);
        console.log("✅ Constraint Added.");
    } catch (err) {
        console.error("❌ Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

addConstraint();
