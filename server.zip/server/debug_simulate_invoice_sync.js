
const http = require('http');

const payload = JSON.stringify({
    tenantId: 'f75b01c2-3911-45f8-928c-0fa649d54ce1',
    invoices: [
        {
            id: '550e8400-e29b-41d4-a716-446655440000', // Valid UUID
            customerName: 'Test Customer Sync',
            amount: 50000,
            vatAmount: 3750,
            status: 'paid',
            dateIssued: new Date().toISOString(),
            items: [{ description: 'Test Item', qty: 1, amount: 50000 }],
            syncStatus: 'pending',
            pdfGeneratedAt: null
        }
    ]
});

const options = {
    hostname: 'localhost',
    port: 3001,
    path: '/api/sync/invoices',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': payload.length
    }
};

console.log("🚀 Sending Simulate Invoice Sync...");
const req = http.request(options, (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => {
        console.log(`\n📬 Status: ${res.statusCode}`);
        console.log("📦 Body:", body);
    });
});

req.on('error', (e) => console.error(`❌ Error: ${e.message}`));
req.write(payload);
req.end();
