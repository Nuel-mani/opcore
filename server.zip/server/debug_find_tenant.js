
const db = require('./db');

async function find() {
    try {
        const res = await db.pool.query("SELECT id, business_name, email FROM tenants WHERE business_name ILIKE '%LAGOS VENTURES%'");
        console.table(res.rows);
    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

find();
