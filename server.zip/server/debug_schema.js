const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

async function test() {
    const client = await pool.connect();
    try {
        console.log('Testing Sectors Table...');
        await client.query(`DROP TABLE IF EXISTS sectors CASCADE;`);
        await client.query(`
            CREATE TABLE sectors (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100) UNIQUE,
                is_exempt_from_small_co_benefit BOOLEAN DEFAULT FALSE,
                description TEXT
            );
        `);
        console.log('Table Created.');

        await client.query(`
            INSERT INTO sectors (name, is_exempt_from_small_co_benefit, description) VALUES
            ('Agriculture', TRUE, 'Exempt')
        `);
        console.log('Insert Success!');

    } catch (err) {
        console.error('Test Failed:', err);
    } finally {
        client.release();
        await pool.end();
    }
}

test();
