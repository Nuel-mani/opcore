
const db = require('./db');

async function listTables() {
    const client = await db.pool.connect();
    try {
        const res = await client.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
        `);
        console.log("📂 Tables in DB:", res.rows.map(r => r.table_name).join(', '));
    } catch (err) {
        console.error("List Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

listTables();
