
const db = require('./db');

async function verifyEdit() {
    const ID = '550e8400-e29b-41d4-a716-446655440000';
    console.log(`🔍 Checking Invoice ${ID}...`);

    try {
        const res = await db.query('SELECT id, customer_name, amount, items, sync_status, updated_at FROM invoices WHERE id = $1', [ID]);

        if (res.rows.length === 0) {
            console.log("❌ Invoice NOT FOUND in Backend.");
        } else {
            const inv = res.rows[0];
            console.log("✅ Invoice Found:");
            console.log(` - Amount: ${inv.amount}`);
            console.log(` - Items: ${JSON.stringify(inv.items)}`);
            console.log(` - Sync Status: ${inv.sync_status}`);
            console.log(` - Updated At: ${inv.updated_at}`);

            // Check for the specific item
            const items = JSON.parse(JSON.stringify(inv.items)); // Ensure it's array
            const foundItem = items.find(i => i.description === 'checking if it working now');

            if (foundItem) {
                console.log("✅ EDITED ITEM FOUND: 'checking if it working now'");
            } else {
                console.log("❌ EDITED ITEM MISSING. Update failed.");
            }
        }
    } catch (e) {
        console.error("Query Failed", e);
    } finally {
        // We generally rely on the pool, but for a script we can just exit
        process.exit(0);
    }
}

verifyEdit();
