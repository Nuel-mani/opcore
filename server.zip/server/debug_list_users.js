
const db = require('./db');

async function list() {
    try {
        const res = await db.pool.query("SELECT id, business_name, email FROM tenants");
        console.table(res.rows);
    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

list();
