
const pg = require('pg');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '.env') });

const pool = new pg.Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

async function checkTenant() {
    try {
        const id = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';
        console.log("Checking Tenant ID:", id);

        const res = await pool.query('SELECT * FROM tenants WHERE id = $1', [id]);

        if (res.rows.length === 0) {
            console.log("Tenant NOT found.");
        } else {
            const t = res.rows[0];
            console.log("--- Tenant Details ---");
            console.log("Business Name:", t.business_name);
            console.log("Address:", t.business_address);
            console.log("Phone:", t.phone_number);
            console.log("TIN:", t.tax_identity_number);
            console.log("Color:", t.brand_color);
            console.log("--------------------");
        }
    } catch (e) {
        console.error("Query Error:", e);
    } finally {
        await pool.end();
    }
}

checkTenant();
