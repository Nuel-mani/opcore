
const db = require('./db');

async function addUpdatedAt() {
    console.log("🛠️ Adding 'updated_at' to invoices...");
    const client = await db.pool.connect();
    try {
        await client.query(`
            ALTER TABLE invoices 
            ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW();
        `);
        console.log("✅ Column added.");
    } catch (err) {
        console.error("❌ Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

addUpdatedAt();
