
const pg = require('pg');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '.env') });

const pool = new pg.Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

async function checkSchema() {
    try {
        const res = await pool.query(`
            SELECT column_name, data_type 
            FROM information_schema.columns 
            WHERE table_name = 'tenants';
        `);
        console.log("=== ACTUAL TENANTS TABLE COLUMNS ===");
        res.rows.forEach(r => console.log(`${r.column_name} (${r.data_type})`));

        const res2 = await pool.query(`
            SELECT column_name, data_type 
            FROM information_schema.columns 
            WHERE table_name = 'brand_change_history';
        `);
        console.log("\n=== ACTUAL BRAND_CHANGE_HISTORY TABLE COLUMNS ===");
        res2.rows.forEach(r => console.log(`${r.column_name} (${r.data_type})`));

        pool.end();
    } catch (err) {
        console.error(err);
        pool.end();
    }
}

checkSchema();
