
const fetch = require('node-fetch'); // Assuming node-fetch is available or using built-in in newer node
// If node-fetch isn't available, I'll use http module. Let's use http to be safe given the environment.
const http = require('http');

const data = JSON.stringify({
    tenantId: 'f75b01c2-3911-45f8-928c-0fa649d54ce1',
    updates: {
        brandColor: '#703e29', // The color the user mentioned
        businessName: 'Lagos Ventures LLC'
    }
});

const options = {
    hostname: 'localhost',
    port: 3001,
    path: '/api/brand/update',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
    }
};

console.log("🚀 Sending Simulate Update Request...");

const req = http.request(options, (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => {
        console.log(`\n📬 Response Status: ${res.statusCode}`);
        console.log("📦 Response Body:", body);
    });
});

req.on('error', (e) => {
    console.error(`❌ Request Error: ${e.message}`);
});

req.write(data);
req.end();
