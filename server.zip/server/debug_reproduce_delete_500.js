
const http = require('http');

const options = {
    hostname: 'localhost',
    port: 3001,
    path: '/api/sync/invoices/550e8400-e29b-41d4-a716-446655440000?tenantId=f75b01c2-3911-45f8-928c-0fa649d54ce1',
    method: 'DELETE',
};

const req = http.request(options, res => {
    console.log(`STATUS: ${res.statusCode}`);

    let data = '';
    res.on('data', chunk => {
        data += chunk;
    });

    res.on('end', () => {
        console.log('BODY: ' + data);
    });
});

req.on('error', error => {
    console.error(error);
});

req.end();
