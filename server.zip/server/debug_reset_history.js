
const db = require('./db');

async function resetBrandHistory() {
    const tenantId = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';
    console.log(`🧹 Clearing Brand History for: ${tenantId}`);

    const client = await db.pool.connect();
    try {
        await client.query('DELETE FROM brand_change_history WHERE tenant_id = $1', [tenantId]);
        console.log("✅ History Cleared. User unbound.");
    } catch (err) {
        console.error("❌ Reset Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

resetBrandHistory();
