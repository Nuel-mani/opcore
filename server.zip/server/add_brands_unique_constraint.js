
const db = require('./db');

async function fixBrandsConstraint() {
    console.log("🔧 Fixing Brands Table Constraint...");
    const client = await db.pool.connect();
    try {
        // 1. Check for duplicates first (and remove them to allow unique constraint)
        await client.query(`
            DELETE FROM brands a USING brands b
            WHERE a.id < b.id AND a.tenant_id = b.tenant_id
        `);
        console.log("🧹 Removed duplicate brand records.");

        // 2. Add Unique Constraint
        await client.query(`
            ALTER TABLE brands 
            ADD CONSTRAINT brands_tenant_id_key UNIQUE (tenant_id);
        `);
        console.log("✅ Added UNIQUE constraint to brands(tenant_id).");

    } catch (err) {
        if (err.code === '42710') {
            console.log("⚠️ Constraint already exists.");
        } else {
            console.error("❌ Constraint Fix Failed", err);
        }
    } finally {
        client.release();
        await db.pool.end();
    }
}

fixBrandsConstraint();
