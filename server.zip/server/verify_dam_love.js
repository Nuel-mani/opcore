
const db = require('./db');

async function check() {
    try {
        const inv = await db.pool.query("SELECT id, customer_name, amount, items, status FROM invoices WHERE customer_name = 'DAM LOVE'");
        const tx = await db.pool.query("SELECT id, invoice_id, amount, description FROM transactions WHERE amount = '69875000.00' AND invoice_id IS NOT NULL");

        console.log('--- INVOICE ---');
        console.log(JSON.stringify(inv.rows, null, 2));
        console.log('--- TRANSACTION ---');
        console.log(JSON.stringify(tx.rows, null, 2));
    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

check();
