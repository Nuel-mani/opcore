
const db = require('./db');

async function repairTables() {
    console.log("🛠️ Starting Database Repair...");
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');

        // 1. Create Invoices Table
        console.log("   - Creating 'invoices' table if missing...");
        await client.query(`
            CREATE TABLE IF NOT EXISTS invoices (
                id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                serial_id SERIAL,
                tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
                customer_name VARCHAR(255),
                amount DECIMAL(19, 2) NOT NULL,
                vat_amount DECIMAL(19, 2) DEFAULT 0,
                status VARCHAR(20) DEFAULT 'draft',
                date_issued DATE DEFAULT CURRENT_DATE,
                items JSONB DEFAULT '[]',
                
                -- Evidence Tracking
                pdf_generated_at TIMESTAMP,
                reprint_count INTEGER DEFAULT 0,

                sync_status VARCHAR(20) DEFAULT 'synced',
                created_at TIMESTAMP DEFAULT NOW()
            );
        `);

        // 2. Add invoice_id to transactions if missing
        console.log("   - Linking 'transactions' to 'invoices'...");
        await client.query(`
            ALTER TABLE transactions 
            ADD COLUMN IF NOT EXISTS invoice_id UUID REFERENCES invoices(id) ON DELETE SET NULL;
        `);

        // 3. Re-Add Triggers
        console.log("   - Re-applying triggers...");

        // Function: turnover check
        await client.query(`
            CREATE OR REPLACE FUNCTION check_turnover_threshold()
            RETURNS TRIGGER AS $$
            DECLARE
                total_sales DECIMAL;
                total_assets DECIMAL;
                professional_service BOOLEAN;
            BEGIN
                -- 1. Calculate Total Sales (Invoices + Ledger Income)
                SELECT (
                    COALESCE((SELECT SUM(amount) FROM invoices WHERE tenant_id = NEW.tenant_id AND status = 'paid'), 0) +
                    COALESCE((SELECT SUM(amount) FROM transactions WHERE tenant_id = NEW.tenant_id AND type = 'income'), 0)
                ) INTO total_sales;

                -- 2. Calculate Total Assets
                SELECT COALESCE(SUM(amount), 0)
                INTO total_assets
                FROM transactions 
                WHERE tenant_id = NEW.tenant_id 
                AND is_capital_asset = TRUE;

                -- 3. Check Sector
                SELECT is_professional_service INTO professional_service
                FROM tenants
                WHERE id = NEW.tenant_id;

                -- Logic
                IF total_sales > 100000000 OR total_assets > 250000000 OR professional_service = TRUE THEN
                    UPDATE tenants 
                    SET turnover_band = CASE 
                            WHEN total_sales > 100000000 THEN 'large' 
                            ELSE 'medium' 
                        END,
                        is_cit_exempt = FALSE, 
                        is_vat_exempt = FALSE 
                    WHERE id = NEW.tenant_id;
                ELSE
                    UPDATE tenants 
                    SET turnover_band = CASE 
                            WHEN total_sales < 25000000 THEN 'micro'
                            ELSE 'small'
                        END,
                        is_cit_exempt = (total_sales < 100000000), 
                        is_vat_exempt = (total_sales < 25000000) 
                    WHERE id = NEW.tenant_id;
                END IF;

                RETURN NEW;
            END;
            $$ LANGUAGE plpgsql;
        `);

        // Trigger on Invoices
        await client.query(`
            DROP TRIGGER IF EXISTS turnover_watch ON invoices;
            CREATE TRIGGER turnover_watch
            AFTER INSERT OR UPDATE ON invoices
            FOR EACH ROW
            EXECUTE PROCEDURE check_turnover_threshold();
        `);

        await client.query('COMMIT');
        console.log("✅ Repair Complete.");

    } catch (err) {
        await client.query('ROLLBACK');
        console.error("❌ Repair Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

repairTables();
