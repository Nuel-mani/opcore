
const db = require('./db');

async function inspect() {
    try {
        console.log("--- LATEST 5 INVOICES ---");
        const inv = await db.pool.query("SELECT id, customer_name, amount, created_at FROM invoices ORDER BY created_at DESC LIMIT 5");
        console.table(inv.rows);

        console.log("\n--- LATEST 5 TRANSACTIONS ---");
        const tx = await db.pool.query("SELECT id, invoice_id, amount, created_at FROM transactions ORDER BY created_at DESC LIMIT 5");
        console.table(tx.rows);

        console.log("\n--- SCHEMA: TRANSACTIONS ---");
        const schema = await db.pool.query("SELECT column_name, is_nullable FROM information_schema.columns WHERE table_name = 'transactions' AND column_name = 'invoice_id'");
        console.table(schema.rows);

    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

inspect();
