# OpCore Backend (Node.js/PostgreSQL)

## Overview
This is the backend server for OpCore, handling data synchronization for the local-first frontend (WatermelonDB), enforcing NTA 2025 tax compliance logic, and managing "God Mode" admin features.

## Prerequisites
- Node.js (v18+)
- PostgreSQL (v14+)
- Supabase (Optional, but schema is compatible)

## Setup

1.  **Install Dependencies**
    ```bash
    cd server
    npm install
    ```

2.  **Environment Variables**
    Create a `.env` file in the `server` directory:
    ```ini
    PORT=3001
    DB_USER=postgres
    DB_PASSWORD=your_password
    DB_HOST=localhost
    DB_PORT=5432
    DB_NAME=OpCore
    ```

3.  **Database Migration**
    Run the schema script to initialize tables and triggers:
    ```bash
    psql -U postgres -d OpCore -f schema.sql
    ```

4.  **Run Development Server**
    ```bash
    npm run dev
    ```
    Server will start on `http://localhost:3001`.

## Key Features

### 1. Synchronization (WatermelonDB)
- **Push**: Clients send offline changes to `/api/sync/push` (Implemented as individual resource POSTs for MVP, migratable to bulk).
- **Pull**: Clients fetch changes since `lastSync`.

### 2. Tax Logic (Triple Constraint)
- **Trigger**: `turnover_watch` on `invoices` and `transactions` tables.
- **Logic**: Automatically upgrades `turnover_band` and revokes `is_tax_exempt` if:
    - Turnover > ₦100M
    - Assets > ₦250M
    - Sector is "Professional Services"

### 3. File Uploads
- Local storage in `public/uploads`.
- Served statically at `/uploads/filename.ext`.

## Deployment
- **Method**: Docker or PM2.
- **Reverse Proxy**: NGINX recommended for SSL termination.
- **Database**: Managed PostgreSQL (Supabase/RDS).
