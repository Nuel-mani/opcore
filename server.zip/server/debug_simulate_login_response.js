
const db = require('./db');

async function simulateLoginResponse() {
    const email = 'lagos.ventures@example.com'; // I need to guess the email or use the ID. 
    // Actually, looking at previous logs (Step 932 output), the tenant ID is 'f75b01c2-3911-45f8-928c-0fa649d54ce1'.
    const tenantId = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';

    console.log(`🕵️ Simulating Login Response logic for ID: ${tenantId}`);

    const client = await db.pool.connect();
    try {
        // Logic copied from server/index.js /api/auth/login (roughly)
        const result = await client.query('SELECT * FROM tenants WHERE id = $1', [tenantId]);
        const tenant = result.rows[0];

        if (!tenant) {
            console.log("❌ Tenant not found in DB");
            return;
        }

        const payload = {
            id: tenant.id,
            email: tenant.email,
            businessName: tenant.business_name,
            accountType: (tenant.account_type || 'personal').toLowerCase(),
            // ...
            brandColor: tenant.brand_color,
            logoUrl: tenant.logo_url,
            // ...
        };

        console.log("📦 Simulated API Response Payload:");
        console.log("   brandColor:", payload.brandColor);
        console.log("   logoUrl:", payload.logoUrl);
        console.log("   Full Payload (Partial):", JSON.stringify({ brandColor: payload.brandColor, id: payload.id }));

    } catch (err) {
        console.error("❌ Error:", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

simulateLoginResponse();
