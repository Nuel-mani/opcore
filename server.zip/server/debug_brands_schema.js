
const db = require('./db');

async function checkBrandsSchema() {
    const client = await db.pool.connect();
    try {
        const res = await client.query(`
            SELECT column_name, data_type 
            FROM information_schema.columns 
            WHERE table_name = 'brands'
        `);
        console.log("🏗️ Brands Table Schema:");
        res.rows.forEach(r => console.log(` - ${r.column_name} (${r.data_type})`));

        // Also check if there is ANY data in it (maybe my previous query filtered by tenant_id and failed?)
        const count = await client.query('SELECT COUNT(*) FROM brands');
        console.log(`\n📊 Total Rows in Brands: ${count.rows[0].count}`);

    } catch (err) {
        console.error("Check Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

checkBrandsSchema();
