
const db = require('./db');

async function verify() {
    try {
        console.log("🔍 Searching for 'Big coco' Invoice...");
        const invRes = await db.pool.query(`
            SELECT id, tenant_id, customer_name, amount, vat_amount, status, items, sync_status, created_at 
            FROM invoices 
            WHERE customer_name ILIKE '%Big coco%'
        `);

        if (invRes.rows.length === 0) {
            console.log("❌ Invoice 'Big coco' NOT FOUND.");
            return;
        }

        const invoice = invRes.rows[0];
        console.log("✅ Invoice Found:");
        console.log(JSON.stringify(invoice, null, 2));

        console.log("\n🔍 Checking for Linked Transaction...");
        const txRes = await db.pool.query(`
            SELECT id, invoice_id, amount, description, type, sync_status 
            FROM transactions 
            WHERE invoice_id = $1
        `, [invoice.id]);

        if (txRes.rows.length === 0) {
            console.log("❌ Linked Transaction NOT FOUND.");
        } else {
            console.log("✅ Linked Transaction Found:");
            console.table(txRes.rows);
        }

    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

verify();
