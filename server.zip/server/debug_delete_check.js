
const db = require('./db');

async function debugDelete404() {
    const invId = '550e8400-e29b-41d4-a716-446655440000';
    const tenantIdFromLog = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';

    console.log(`🔍 Checking Invoice: ${invId}`);
    try {
        const res = await db.query('SELECT id, tenant_id FROM invoices WHERE id = $1', [invId]);
        if (res.rows.length === 0) {
            console.log("❌ Invoice NOT FOUND in DB. (So 404 is correct/idempotent)");
        } else {
            const row = res.rows[0];
            console.log("✅ Invoice FOUND in DB.");
            console.log(`   - Invoice Tenant: ${row.tenant_id}`);
            console.log(`   - Request Tenant: ${tenantIdFromLog}`);

            if (row.tenant_id === tenantIdFromLog) {
                console.log("✅ Tenants MATCH. Logic should pass.");
                console.log("👉 CONCLUSION: If logic passes but you get 404, the Endpoint likely DOES NOT EXIST yet (Server Restart Required).");
            } else {
                console.log("❌ Tenant MISMATCH. This explains the 404 (Access Denied logic).");
            }
        }
    } catch (e) {
        console.error(e);
    } finally {
        process.exit(0);
    }
}

debugDelete404();
