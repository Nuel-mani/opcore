
const db = require('./db');

async function testBrandsQuery() {
    const tenantId = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';
    const newColor = '#991199'; // Distinct test color

    console.log(`🧪 Testing Brands Upsert for ${tenantId} -> ${newColor}`);
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');

        // The EXACT query from index.js
        const res = await client.query(`
            INSERT INTO brands (tenant_id, brand_color, logo_url, created_at, updated_at)
            VALUES ($1, $2, $3, NOW(), NOW())
            ON CONFLICT ON CONSTRAINT brands_tenant_id_key
            DO UPDATE SET 
                brand_color = COALESCE(EXCLUDED.brand_color, brands.brand_color),
                logo_url = COALESCE(EXCLUDED.logo_url, brands.logo_url),
                updated_at = NOW()
            RETURNING *
        `, [
            tenantId,
            newColor,
            null
        ]);

        console.log("✅ Query Result:", res.rows[0]);
        await client.query('ROLLBACK'); // Rollback so we don't mess up data permanent, just checking syntax
        console.log("🔄 Rolled back test transaction.");

    } catch (err) {
        console.error("❌ Query FAILED:", err.message); // This will tell me if 'brands_tenant_id_key' is invalid
        await client.query('ROLLBACK');
    } finally {
        client.release();
        await db.pool.end();
    }
}

testBrandsQuery();
