
const db = require('./db');

async function listBrandsConstraints() {
    console.log("🔍 Listing Brands Table Constraints & Indexes...");
    const client = await db.pool.connect();
    try {
        // List Constraints
        const constraints = await client.query(`
            SELECT conname, contype, pg_get_constraintdef(oid) 
            FROM pg_constraint 
            WHERE conrelid = 'brands'::regclass
        `);
        console.log("\n🔗 Constraints:");
        constraints.rows.forEach(r => console.log(` - ${r.conname} (${r.contype}): ${r.pg_get_constraintdef}`));

        // List Indexes
        const indexes = await client.query(`
            SELECT indexname, indexdef 
            FROM pg_indexes 
            WHERE tablename = 'brands'
        `);
        console.log("\n📑 Indexes:");
        indexes.rows.forEach(r => console.log(` - ${r.indexname}: ${r.indexdef}`));

    } catch (err) {
        console.error("❌ List Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

listBrandsConstraints();
