
const db = require('./db');

async function checkBrandData() {
    const tenantId = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';
    console.log(`🔍 Checking Brand Data for Tenant: ${tenantId}`);

    const client = await db.pool.connect();
    try {
        // 1. List all tables to see if 'brands' exists
        const tables = await client.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
        `);
        console.log("\n📂 Tables in DB:", tables.rows.map(r => r.table_name).join(', '));

        // 2. Check Tenants Table
        const tenant = await client.query('SELECT id, business_name, brand_color, sector FROM tenants WHERE id = $1', [tenantId]);
        console.log("\n👤 Tenant Record:");
        if (tenant.rows.length > 0) {
            console.log(tenant.rows[0]);
        } else {
            console.log("No tenant found.");
        }

        // 3. Check Brand Change History
        const history = await client.query('SELECT * FROM brand_change_history WHERE tenant_id = $1 ORDER BY created_at DESC LIMIT 5', [tenantId]);
        console.log("\n📜 Brand Change History (Last 5):");
        history.rows.forEach(r => {
            console.log(` - [${r.created_at}] ${r.change_type}: ${r.old_value} -> ${r.new_value}`);
        });

        // 4. Check 'brands' table if it exists
        if (tables.rows.find(r => r.table_name === 'brands')) {
            const brands = await client.query('SELECT * FROM brands WHERE tenant_id = $1', [tenantId]);
            console.log("\n🏷️ Brands Table Record:");
            console.log(brands.rows);
        } else {
            console.log("\n🚫 No 'brands' table found.");
        }

    } catch (err) {
        console.error("❌ Brand Check Failed", err);
        // Maybe theme_color column doesn't exist, which is fine, catch it.
    } finally {
        client.release();
        await db.pool.end();
    }
}

checkBrandData();
