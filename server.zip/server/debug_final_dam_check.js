
const db = require('./db');

async function check() {
    try {
        const res = await db.pool.query("SELECT id, customer_name, amount, status FROM invoices WHERE customer_name ILIKE '%DAM LOVE%'");
        if (res.rows.length === 0) {
            console.log("❌ 'DAM LOVE' invoice NOT found in backend.");
        } else {
            console.log("✅ Found 'DAM LOVE':", res.rows);
        }
    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

check();
