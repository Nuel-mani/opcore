
const db = require('./db');

async function check() {
    try {
        console.log("Checking for invoices for tenant: f75b01c2-3911-45f8-928c-0fa649d54ce1");
        const res = await db.pool.query("SELECT id, customer_name, amount, date_issued, created_at FROM invoices WHERE tenant_id = 'f75b01c2-3911-45f8-928c-0fa649d54ce1'");
        console.table(res.rows);
    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

check();
