
const db = require('./db');

async function check() {
    try {
        const id = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';
        console.log(`Checking Tenant ID: ${id}`);
        const res = await db.pool.query("SELECT id, business_name, email FROM tenants WHERE id = $1", [id]);
        if (res.rows.length === 0) {
            console.log("❌ Tenant NOT FOUND.");
        } else {
            console.log("✅ Tenant Found:", res.rows[0]);
        }
    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

check();
