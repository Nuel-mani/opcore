
const db = require('./db');

async function backfillBrands() {
    console.log("🔄 Starting Brands Backfill...");
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');

        // 1. Get all tenants who are missing from the brands table
        const missingTenants = await client.query(`
            SELECT t.id, t.business_name, t.brand_color, t.logo_url
            FROM tenants t
            LEFT JOIN brands b ON t.id = b.tenant_id
            WHERE b.id IS NULL
        `);

        if (missingTenants.rows.length === 0) {
            console.log("✅ No missing brand records found. All synced.");
        } else {
            console.log(`⚠️ Found ${missingTenants.rows.length} tenants without brand records. Backfilling...`);

            for (const tenant of missingTenants.rows) {
                console.log(`   - Backfilling for: ${tenant.business_name} (${tenant.id})`);

                // Insert into brands table
                await client.query(`
                    INSERT INTO brands (tenant_id, brand_color, logo_url, created_at, updated_at)
                    VALUES ($1, $2, $3, NOW(), NOW())
                    ON CONFLICT ON CONSTRAINT brands_tenant_id_key DO NOTHING
                `, [
                    tenant.id,
                    tenant.brand_color || '#2252c9', // Default blue if null
                    tenant.logo_url
                ]);
            }
            console.log("✅ Backfill Complete.");
        }

        await client.query('COMMIT');

        // Verify Status
        const totalTenants = await client.query('SELECT count(*) FROM tenants');
        const totalBrands = await client.query('SELECT count(*) FROM brands');
        console.log(`\n📊 Status Update:`);
        console.log(` - Total Tenants: ${totalTenants.rows[0].count}`);
        console.log(` - Total Brand Records: ${totalBrands.rows[0].count}`);

    } catch (err) {
        await client.query('ROLLBACK');
        console.error("❌ Backfill Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

backfillBrands();
