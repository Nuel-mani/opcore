
const db = require('./db');

async function checkInvoiceSchema() {
    const client = await db.pool.connect();
    try {
        console.log("🔍 Checking Invoices Table Schema...");
        const res = await client.query(`
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns 
            WHERE table_name = 'invoices'
        `);
        res.rows.forEach(r => console.log(` - ${r.column_name} (${r.data_type}) [${r.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'}]`));

        console.log("\n🔍 Checking Invoices Data (Count)...");
        const count = await client.query('SELECT COUNT(*) FROM invoices');
        console.log(`   Total Rows: ${count.rows[0].count}`);

    } catch (err) {
        console.error("Check Failed", err);
    } finally {
        client.release();
        await db.pool.end();
    }
}

checkInvoiceSchema();
