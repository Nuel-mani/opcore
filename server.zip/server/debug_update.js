
const db = require('./db');

async function debugUpdate() {
    const client = await db.pool.connect();
    try {
        console.log("🚀 Starting Debug Update...");

        // Mock Request Body (from User's Screenshot/Issue)
        const tenantId = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';
        const updates = {
            businessName: "Lagos Ventures LLC",
            businessAddress: "5259 W 500 N",
            phoneNumber: "13175153326",
            tinNumber: "32456586325", // Note: Component sends 'taxIdentityNumber' OR this? Component sends taxIdentityNumber: taxId. Wait.
            // Let's check BrandConfigurator.tsx line 30: taxIdentityNumber: taxId.
            // So key is taxIdentityNumber.
            taxIdentityNumber: "32456586325",
            brandColor: "#D49F7E",
            themeColor: "#D49F7E",
            invoiceTemplate: "Modern", // Component sends 'invoiceTemplate: template'
            invoiceFont: "Inter (Clean)", // Component sends 'invoiceFont: font'
            showWatermark: false
        };

        const restrictedFields = ['brand_color', 'logo_url', 'business_address', 'phone_number', 'business_name', 'tax_identity_number', 'stamp_url', 'invoice_template', 'invoice_font', 'show_watermark'];

        // BUG 1: This filter logic is likely wrong because keys are camelCase
        const fieldsToUpdate = updates ? Object.keys(updates).filter(k => restrictedFields.includes(k)) : [];
        console.log("Fields to Update (History):", fieldsToUpdate);

        await client.query('BEGIN');

        // Logic from index.js
        const setClauses = [];
        const values = [tenantId];
        let idx = 2;

        const dbFieldMap = {
            businessName: 'business_name',
            businessAddress: 'business_address',
            phoneNumber: 'phone_number',
            tinNumber: 'tax_identity_number',
            taxIdentityNumber: 'tax_identity_number',
            brandColor: 'brand_color',
            logoUrl: 'logo_url',
            stampUrl: 'stamp_url',
            invoiceTemplate: 'invoice_template',
            invoiceFont: 'invoice_font',
            showWatermark: 'show_watermark'
        };

        const currentTenant = await client.query('SELECT * FROM tenants WHERE id = $1', [tenantId]);
        const oldData = currentTenant.rows[0];
        if (!oldData) throw new Error("Tenant Not Found");

        for (const [key, value] of Object.entries(updates)) {
            const dbKey = dbFieldMap[key] || key;

            // SECURITY CHECK
            if (restrictedFields.includes(dbKey)) {
                setClauses.push(`${dbKey} = $${idx}`);
                values.push(value);
                idx++;
                console.error(`[MATCH] ${key} -> ${dbKey}`);
            } else {
                console.error(`[SKIP] ${key} -> ${dbKey} (Not in whitelist)`);
            }
        }

        console.error("Set Clauses:", setClauses);
        console.error("Values:", values);

        if (setClauses.length > 0) {
            const queryText = `
                UPDATE tenants 
                SET ${setClauses.join(', ')}, updated_at = NOW()
                WHERE id = $1
            `;
            console.error("Executing Query:", queryText);

            await client.query(queryText, values);

            // History Loop (Fixed Logic Simulation)
            for (const [key, value] of Object.entries(updates)) {
                const dbKey = dbFieldMap[key] || key;
                if (restrictedFields.includes(dbKey)) {
                    // console.error("History Insert for", dbKey);
                }
            }

        } else {
            console.error("⚠️ No clauses to update! This might cause syntax error if logic continues.");
        }

        await client.query('ROLLBACK'); // Always rollback test
        console.log("✅ Simulation Complete (Rolled Back)");

    } catch (err) {
        console.error("❌ UPDATE FAILED:", err);
        if (client) await client.query('ROLLBACK');
    } finally {
        if (client) client.release();
        await db.pool.end();
    }
}

debugUpdate();
