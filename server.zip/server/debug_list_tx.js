
const db = require('./db');

async function debugListTransactions() {
    console.log("🔍 Checking Backend Transactions...");
    try {
        const res = await db.query('SELECT id, description, amount, sync_status, tenant_id FROM transactions ORDER BY created_at DESC LIMIT 5');
        if (res.rows.length === 0) {
            console.log("❌ NO TRANSACTIONS found in Backend.");
        } else {
            console.log("✅ Found Transactions:");
            res.rows.forEach(r => {
                console.log(` - [${r.sync_status}] ${r.description} (${r.amount})`);
            });
        }
    } catch (e) {
        console.error(e);
    } finally {
        process.exit(0);
    }
}

debugListTransactions();
