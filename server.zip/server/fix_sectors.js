
const pg = require('pg');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '.env') });

const pool = new pg.Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const SECTORS_TO_ADD = [
    { name: 'general', description: 'General Trading and Business' },
    { name: 'agriculture', description: 'Farming and Agriculture' },
    { name: 'manufacturing', description: 'Production and Manufacturing' },
    { name: 'tech', description: 'Technology and Software' },
    { name: 'retail', description: 'Retail Stores' },
    { name: 'finance', description: 'Financial Services' },
    { name: 'education', description: 'Schools and Training' },
    { name: 'health', description: 'Healthcare and Hospitals' }
];

async function fixSectors() {
    const client = await pool.connect();
    try {
        console.log("🚀 Starting Sector Fix...");
        await client.query('BEGIN');

        // 1. Insert Missing Sectors
        for (const s of SECTORS_TO_ADD) {
            const res = await client.query(`
                INSERT INTO sectors (name, description) 
                VALUES ($1, $2) 
                ON CONFLICT (name) DO UPDATE SET description = EXCLUDED.description
                RETURNING id;
            `, [s.name, s.description]);
            // console.log(`✓ Ensure Sector: ${s.name} (ID: ${res.rows[0]?.id})`);
        }
        console.log("✓ Sectors Populated");

        // 2. Fix Tenants with NULL sector_id but valid text sector
        // We will loop through the added sectors and link them.
        for (const s of SECTORS_TO_ADD) {
            const secRes = await client.query('SELECT id FROM sectors WHERE name = $1', [s.name]);
            if (secRes.rows.length > 0) {
                const secId = secRes.rows[0].id;

                // Update tenants who have this sector name but no ID
                const updateRes = await client.query(`
                    UPDATE tenants 
                    SET sector_id = $1 
                    WHERE sector = $2 AND sector_id IS NULL
                    RETURNING id
                `, [secId, s.name]);

                if (updateRes.rowCount > 0) {
                    console.log(`✓ Fixed ${updateRes.rowCount} tenants for sector '${s.name}'`);
                }
            }
        }

        // 3. Fallback: Fix specified tenant 'f75b01c2-3911-45f8-928c-0fa649d54ce1' if still broken
        // If it had 'general' it should be fixed above.
        // Let's verify.
        const targetId = 'f75b01c2-3911-45f8-928c-0fa649d54ce1';
        const verify = await client.query('SELECT sector, sector_id FROM tenants WHERE id = $1', [targetId]);
        if (verify.rows.length > 0) {
            console.log("🔍 Verification for Tenant", targetId, ":", verify.rows[0]);
        }

        await client.query('COMMIT');
        console.log("✅ Fix Complete!");
    } catch (e) {
        await client.query('ROLLBACK');
        console.error("❌ Fix Failed", e);
    } finally {
        client.release();
        await pool.end();
    }
}

fixSectors();
