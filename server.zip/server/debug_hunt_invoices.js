
const db = require('./db');

async function hunt() {
    try {
        console.log("🔍 Hunting for ANY recent invoices...");
        // Select last 10 created invoices globally
        const res = await db.pool.query(`
            SELECT id, tenant_id, customer_name, amount, created_at, items 
            FROM invoices 
            ORDER BY created_at DESC 
            LIMIT 10
        `);
        console.table(res.rows);
    } catch (e) {
        console.error(e)
    } finally {
        await db.pool.end();
    }
}

hunt();
